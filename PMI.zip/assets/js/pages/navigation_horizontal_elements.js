/* ------------------------------------------------------------------------------
*
*  # Horizontal navigation with elements
*
*  Specific JS code additions for navigation_horizontal_elements.html page
*
*  Version: 1.0
*  Latest update: Aug 1, 2015
*
* ---------------------------------------------------------------------------- */

$(function() {

	// Switchery toggle inside navbar
    var switchery = document.querySelector('.navbar-switch');
    var init = new Switchery(switchery, {secondaryColor: '#000'});

});
