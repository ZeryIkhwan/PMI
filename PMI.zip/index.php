<!DOCTYPE html>
<?php
include "db-connect.php";
include "login-code.php";
 ?>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PMI</title>

	<!-- Global stylesheets -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
	<link href="assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
	<link href="assets/css/minified/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/minified/core.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/minified/components.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/minified/colors.min.css" rel="stylesheet" type="text/css">
	<!-- /global stylesheets -->

	<!-- Core JS files -->
	<script type="text/javascript" src="assets/js/plugins/loaders/pace.min.js"></script>
	<script type="text/javascript" src="assets/js/core/libraries/jquery.min.js"></script>
	<script type="text/javascript" src="assets/js/core/libraries/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/plugins/loaders/blockui.min.js"></script>
	<!-- /core JS files -->


	<!-- Theme JS files -->
	<script type="text/javascript" src="assets/js/core/app.js"></script>
	<!-- /theme JS files -->
	<script type="text/javascript">
		function showpass()
		{
			$('#password').attr('type', 'text');
		}

		function hidepass()
		{
			$('#password').attr('type', 'password');
		}

        </script>

</head>

<body class= "bg-slate-800  pace-done">
	<!-- Page container -->
	<div class="page-container login-container">

		<!-- Page content -->
		<div class="page-content">

			<!-- Main content -->
			<div class="content-wrapper">

				<!-- Content area -->
				<div class="content">

					<!-- Simple login form -->
					<form action="" method="post">
						<div class="panel panel-body login-form">
							<div class="text-center">
								<div class="icon-object border-slate-300 text-slate-300"><i class="icon-reading"></i></div>
								<h5 class="content-group">Login Admin <small class="display-block">Enter your credentials below</small></h5>
							</div>

							<div class="form-group has-feedback has-feedback-right">
								<div class="input-group">
								<div class="input-group-addon"><i class="icon-user"></i></div>
								<input type="text" class="form-control" placeholder="Username / Email" id="username" name="username" onkeypress="nextpass(event);">
								<!--<div class="form-control-feedback">
									<i class="icon-user text-muted"></i>-->
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-right">
								<div class="input-group">
								<div class="input-group-addon"><i class="icon-lock2"></i></div>
								<input type="password" class="form-control" placeholder="Password" id="password" name="password" onkeypress="prslogin(event);">
									<div class="input-group-addon"><i class="icon-eye2 text-muted" onMouseOver="showpass()" onMouseOut="hidepass()" ></i></div>
								</div>
							</div>

							<div class="form-group">
								<button type="submit" name="login" class="btn btn-danger btn-block">Sign in <i class="icon-circle-right2 position-right"></i></button>
							</div>

							<div class="text-center">
								<a href="forgot-password.php">Forgot password?</a>
							</div>
						</div>
					</form>
					<!-- /simple login form -->


					<!-- Footer -->
					<div class="footer text-muted">
						&copy; 2015. <a href="http://www.politeknikaceh.ac.id/">Politeknik Aceh</a>
					</div>
					<!-- /footer -->

				</div>
				<!-- /content area -->

			</div>
			<!-- /main content -->

		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->

</body>
</html>
