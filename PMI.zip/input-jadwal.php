<!DOCTYPE html>
<?php
include "db-connect.php";
ob_start();
session_start();
if(!isset($_SESSION['username']))
{
  header("location:index.php");
}
else
extract($_POST);
$username=$_SESSION['username'];

$sql2 ="SELECT * FROM tb_login";
$database2 = mysqli_query($koneksi,$sql2);
while ($data2 = mysqli_fetch_array($database2)){
$iduser = $data2['id'];

$txtempat="";
$txalamat="";
$txtanggal="";
$txwaktu="";
$txid=0;
$update=false;

if(isset($_GET['edit'])){
  $txid = $_GET['edit'];
  $update = true;
  $query = "SELECT * FROM tb_jadwal WHERE id=$txid";
  $update = mysqli_query($koneksi,$query);
  if(count($update)==1 ){
    $n = mysqli_fetch_array($update);
    $txtempat=$n['tempat'];
    $txalamat=$n['alamat'];
    $txtanggal=$n['tanggal'];
    $txwaktu=$n['waktu'];
  }
}
?>

<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dashboard</title>

  <!-- Global stylesheets -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
	<link href="assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
	<link href="assets/css/minified/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/minified/core.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/minified/components.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/minified/colors.min.css" rel="stylesheet" type="text/css">
	<!-- /global stylesheets -->

	<!-- Core JS files -->
	<script type="text/javascript" src="assets/js/plugins/loaders/pace.min.js"></script>
	<script type="text/javascript" src="assets/js/core/libraries/jquery.min.js"></script>
	<script type="text/javascript" src="assets/js/core/libraries/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/plugins/loaders/blockui.min.js"></script>
	<!-- /core JS files -->

	<!-- Theme JS files -->
	<script type="text/javascript" src="assets/js/plugins/visualization/d3/d3.min.js"></script>
	<script type="text/javascript" src="assets/js/plugins/visualization/d3/d3_tooltip.js"></script>
	<script type="text/javascript" src="assets/js/plugins/forms/styling/switchery.min.js"></script>
	<script type="text/javascript" src="assets/js/plugins/forms/styling/uniform.min.js"></script>
	<script type="text/javascript" src="assets/js/plugins/forms/selects/bootstrap_multiselect.js"></script>
	<script type="text/javascript" src="assets/js/plugins/ui/moment/moment.min.js"></script>
	<script type="text/javascript" src="assets/js/plugins/pickers/daterangepicker.js"></script>

	<!-- /theme JS files -->

  <!-- script datatables -->
  <script type="text/javascript" src="assets/js/plugins/tables/datatables/datatables.min.js"></script>
	<script type="text/javascript" src="assets/js/plugins/forms/selects/select2.min.js"></script>

	<script type="text/javascript" src="assets/js/core/app.js"></script>
	<script type="text/javascript" src="assets/js/pages/datatables_advanced.js"></script>
  <!-- /script datatables -->

  <script type="text/javascript" src="assets/js/plugins/notifications/sweet_alert.min.js"></script>

</head>

<body>

	<!-- Main navbar -->
	<div class="navbar navbar-inverse">
		<div class="navbar-header">
			<a class="navbar-brand" href="dashboard.php"><img src="assets/images/logo_light.png" alt=""></a>

			<ul class="nav navbar-nav visible-xs-block">
				<li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
				<li><a class="sidebar-mobile-main-toggle"><i class="icon-paragraph-justify3"></i></a></li>
			</ul>
		</div>

		<div class="navbar-collapse collapse" id="navbar-mobile">
			<ul class="nav navbar-nav">
				<li><a class="sidebar-control sidebar-main-toggle hidden-xs"><i class="icon-paragraph-justify3"></i></a></li>
			</ul>

			<ul class="nav navbar-nav navbar-right">

				<li class="dropdown dropdown-user">
					<a class="dropdown-toggle" data-toggle="dropdown">
						<img src="assets/images/placeholder.jpg" alt="">
						<span><?php echo $username;?></span>
						<i class="caret"></i>
					</a>

					<ul class="dropdown-menu dropdown-menu-right">
						<li><a href="tambahadmin.php"><i class="icon-user-plus"></i> My profile</a></li>
						<li class="divider"></li>
						<li><a  id="login" data-target="#modalinfo" data-toggle="modal"><i class="icon-cog5"></i> Change Password</a></li>
						<li><a href="logout.php"><i class="icon-switch2"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<!-- /main navbar -->


	<!-- Page container -->
	<div class="page-container">

		<!-- Page content -->
		<div class="page-content">

			<!-- Main sidebar -->
			<div class="sidebar sidebar-main">
				<div class="sidebar-content">

					<!-- Main navigation -->
					<div class="sidebar-category sidebar-category-visible">
						<div class="category-content no-padding">
							<ul class="navigation navigation-main navigation-accordion">

								<!-- Main -->
								<li class="navigation-header"><span>Main</span> <i class="icon-menu" title="Main pages"></i></li>
								<li class="active"><a href="dashboard.php"><i class="icon-home4"></i> <span>Dashboard</span></a></li>
								<!-- /main -->

								<!-- Forms -->
								<li class="navigation-header"><span>Forms</span> <i class="icon-menu" title="Forms"></i></li>

								<li>
									<a href="data-pendonor.php"><i class="icon-folder-heart"></i> <span>Data Pendonor</span></a>
									<a href="input-jadwal.php"><i class="icon-folder-plus"></i><span>Input Jadwal Donor</span></a>
									<a href="qr-code.php"><i class="icon-qrcode"></i><span>Qr Code</span></a>
								</li>
								<!-- /forms -->
							</ul>
						</div>
					</div>
					<!-- /main navigation -->

				</div>
			</div>
			<!-- /main sidebar -->


			<!-- Main content -->
			<div class="content-wrapper">

				<!-- Page header -->
				<div class="page-header">
					<div class="page-header-content">
						<div class="page-title">
							<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Home</span> - Jadwal Mobil Unit</h4>
						</div>
					</div>

					<div class="breadcrumb-line">
						<ul class="breadcrumb">
							<li><a href="dashboard.php"><i class="icon-home2 position-left"></i> Home</a></li>
							<li class="active">Jadwal</li>
						</ul>
					</div>
				</div>
				<!-- /page header -->

				<!-- Content area -->
				<div class="content">

          <!-- Single button -->
          <div class="row">
						<div class="col-md-5">
							<div class="panel panel-danger border-top-danger-800">
								<div class="panel-heading">
									<h6 class="panel-title">Form Input Jadwal</h6>
								</div>
								<div class="panel-body">
									<form class="form-horizontal" action="simpan-jadwal.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $txid; ?>">
									<div class="form-group">
											<label class="col-lg-3 control-label">Tempat :</label>
											<div class="col-lg-9">
												<input type="text" name="tempat" value="<?php echo $txtempat; ?>" class="form-control">
											</div>
										</div>
										<div class="form-group">
											<label class="col-lg-3 control-label">Alamat :</label>
											<div class="col-lg-9">
                        <input type="text" name="alamat" value="<?php echo $txalamat; ?>" class="form-control">
											</div>
										</div>
										<div class="form-group">
											<label class="col-lg-3 control-label">Tanggal :</label>
											<div class="col-lg-9">
												<input type="date" name="tanggal" value="<?php echo $txtanggal; ?>" class="form-control">
											</div>
										</div>
										<div class="form-group">
											<label class="col-lg-3 control-label">Waktu :</label>
											<div class="col-lg-9">
                        <input type="time" name="waktu" value="<?php echo $txwaktu; ?>" class="form-control">
											</div>
										</div>


									</fieldset>
									<div class="text-right">
                    <?php if ($update == true): ?>
                      <button type="reset" class="btn btn-default">Reset <i class="icon-reload-alt position-right"></i></button>&nbsp;&nbsp;&nbsp;&nbsp;
                      <a href="input-jadwal.php" class="btn btn-default">Cancle <i class="icon-cancel-square position-right"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
                      <button class="btn btn-primary" title="update" name="update"><i class="icon icon-folder"></i></button>
                    <?php else : ?>
                      <button type="reset" class="btn btn-default">Reset <i class="icon-reload-alt position-right"></i></button>&nbsp;&nbsp;&nbsp;&nbsp;
  										<button class="btn btn-primary" name="simpan" title="Simpan"><i class="icon icon-folder"></i></button>
                    <?php endif ?>

									</div>
									</form>
								</div>
							</div>
						</div>

						<div class="col-md-7">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<h6 class="panel-title">Daftar Jadwal Mobil Unit</h6>
								</div>
								<div class="panel-body">
                  <div class="table-responsive">
									<table id="master" class="table table-bordered table-hover datatable-highlight">
										<thead>
											<tr>
                        <th>Id</th>
											  <th>Tempat</th>
											  <th>Alamat</th>
												<th>Tanggal</th>
												<th>Waktu</th>
												<th class="text-center">Actions</th>
											</tr>
										</thead>
										<tbody>
                      <?php
                      $sql ="SELECT * FROM tb_jadwal";
                      $database = mysqli_query($koneksi,$sql);
                      while ($data = mysqli_fetch_array($database)){
                      $waktu = $data['waktu'];
                      $id = $data['id'];
                      $tempat = $data['tempat'];
                      $alamat = $data['alamat'];
                      $tanggal = $data['tanggal'];

                      ?>
											<tr>
                      <td><?php echo $i; ?></td>
											<td><?php echo $tempat ?></td>
											<td><?php echo $alamat ?></td>
											<td><?php echo date ("d-m-Y", strtotime($tanggal)); ?></td>
											<td><?php echo $waktu ?></td>
											<td class="text-center">
												<a class="tip" href="input-jadwal.php?edit=<?php echo "$id"; ?>" title="Edit"><i class="icon-pencil"></i></a>
												<a class="deletenya" title="Delete" onclick="tes('<?php echo $id;?>','<?php echo $tempat;?>')"><i class="icon-trash"></i></a>
											</td>
											</tr>
                    <?php } ?>
										</tbody>
									</table>
                </div>
								</div>
							</div>
						</div>
					</div>
          <!-- /single button -->

          <!-- Ubah Password -->
          <div id="modalinfo" class="modal fade" >
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header bg-primary">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <button class="close modalMinimize"> <i class='fa fa-minus'></i> </button>
                  <h6 class="modal-title">Rubah Password</h6>
                </div>
                <div class="modal-body">

                  <form action="#" class="form-horizontal" method="post">
                    <input type="hidden" name="idusernya" class="form-control" id="idusernya" readonly>
                    <div class="panel panel-flat">
                      <div class="panel-body">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label class="col-lg-3 control-label">Password Baru</label>
                              <div class="col-lg-6">
                              <input type="hidden" name="idpass" id="idpass" value="<?php echo $iduser; ?>"<?php } ?>>
                              <input type="password" class="form-control" placeholder="Isi Password Baru" name="newpass" id="newpass">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="col-lg-3 control-label">Password Lama</label>
                              <div class="col-lg-6">
                              <input type="password" class="form-control" placeholder="Isi Password Lama" name="oldpass" id="oldpass">
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="text-right">
                          <button class="btn btn-primary" name="btsimpan" id="btsimpan">Simpan<i class="icon-floppy-disk position-right"></i></button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <!-- /Ubah Password -->

					<!-- Footer -->
					<div class="footer text-muted">
						&copy; 2015.<a href="http://www.politeknikaceh.ac.id/">Politeknik Aceh</a>
					</div>
					<!-- /footer -->

				</div>
				<!-- /content area -->

			</div>
			<!-- /main content -->

		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->

</body>

<!-- script ubah password -->
<script type="text/javascript">
  $(document).ready(function(){
    $('#btsimpan').click(function(){
      $.ajax({
        url:'ubahpass.php'
      });
      // var idpass = $('#idpass').val();
      // var newpass = $('#newpass').val();
      // var oldpass = $('#oldpass').val();
      // if(newpass != '' && oldpass != '')
      // {
      //     $.ajax({
      //       url:'ubahpass.php',
      //       method:'POST',
      //       data:{newpass:newpass, oldpass:oldpass},
      //       success:function(data){
      //
      //       }
      //     });
      // }
      // else
      // {
      //     alert ("Both need");
      // }
    });
  });
</script>
<!-- /end script ubah password -->

<script type="text/javascript">
function tes(x,y)
{
    swal({
        title: "Confirmation ",
        text: "Data Tempat "+y+" will be deleted ?",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#EF5350",
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No, cancel pls!",
        closeOnConfirm: false,
        closeOnCancel: false
    },
    function(isConfirm){
        if (isConfirm) {
			if (window.XMLHttpRequest)
			{// code for IE7+, Firefox, Chrome, Opera, Safari
				xmlhttp=new XMLHttpRequest();
			}
			else
			{// code for IE6, IE5
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange=function()
			{
				if (xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					var pesan=xmlhttp.responseText;
					if (pesan)
					{
						swal({
							title: "Deleted!",
							text: "Data Has Been Deleted !",
							confirmButtonColor: "#66BB6A",
							type: "success"
						});
						//direset();
						window.location.href="input-jadwal.php";
					}
				}
			}
			xmlhttp.open("GET","delete-jadwal.php?kode=<?php echo $id ?>="+x,true);
			xmlhttp.send(null);
        }
        else {
            swal({
                title: "Cancelled",
                //text: "Proses Hapus Tidak Dilakukan  :)",
                confirmButtonColor: "#2196F3",
                type: "error"
            });
        }
    });
}

$('.datatable-responsivet').DataTable({
	dom: "frtip",
    autoWidth: false,
    responsive: true,
	"oLanguage": {
		"sSearch": "Search&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
	}
});
</script>
</html>
