<?php
include "db-connect.php";
session_start();

$message="Username and Password is invalid";

if (isset($_POST['login']))
{
  $username = $_POST['username'];
  $password = $_POST['password'];
  // Untuk Melindungi data MySQL Injection
  $username = stripslashes($username);
  $password = stripslashes($password);
  $username = mysqli_real_escape_string($koneksi, $username);
  $password = mysqli_real_escape_string($koneksi, $password);

  $query = mysqli_query($koneksi, "SELECT * FROM tb_login WHERE username='$username' AND password='$password'");
  $row = mysqli_num_rows($query);

  if($row==1)
  {
    $_SESSION['username']=$username;
    $_SESSION['id'];
    header("Location:dashboard.php");
  }
  else
  {
    echo "<script type='text/javascript'>alert('$message');</script>";
  }
  mysqli_close($koneksi);
}
?>
