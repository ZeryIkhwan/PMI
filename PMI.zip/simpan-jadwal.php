<?php
include "db-connect.php";

if (isset($_POST['simpan'])){

  $tempat = $_POST['tempat'];
  $alamat = $_POST['alamat'];
  $tanggal = $_POST['tanggal'];
  $waktu = $_POST['waktu'];

  $message = "Data Gagal Disimpan";

  // input data ke MySQL
  $query = "INSERT INTO tb_jadwal (tempat,alamat,tanggal,waktu)values('$tempat','$alamat','$tanggal','$waktu')";
  mysqli_query($koneksi,$query);

  // mengalihkan halaman
  header("location:input-jadwal.php");
}
else {
  ?>
  <?php echo "<script type='text/javascript'>alert('$message');</script>"; ?>
  <?php
}

if (isset($_POST['update'])){
  $tempat = $_POST['tempat'];
  $alamat = $_POST['alamat'];
  $tanggal = $_POST['tanggal'];
  $waktu = $_POST['waktu'];
  $id = $_POST['id'];

  $message = "Data Gagal Disimpan";

  // Update data ke MySQL
  $query = "UPDATE tb_jadwal SET tempat='$tempat',alamat='$alamat',tanggal='$tanggal',waktu='$waktu' WHERE id=$id";
  mysqli_query($koneksi,$query);

  // mengalihkan halaman
  header("location:input-jadwal.php");
}
else {
  ?>
  <?php echo "<script type='text/javascript'>alert('$message');</script>"; ?>
  <?php
}
 ?>
