<?php
include "db-connect.php";

if (isset($_POST['newpass']))
{
  $sql  = mysqli_query("SELECT * FROM tb_login WHERE id=$iduser");
  $data = mysqli_fetch_array($sql);

}
